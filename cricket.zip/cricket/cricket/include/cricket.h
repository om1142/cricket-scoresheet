#ifndef CRICKET_H
#define CRICKET_H


class cricket
{
    public:
        void inning1();
        void inning2();
        void toss();
        void innings();
        void winner();
};

#endif // CRICKET_H
