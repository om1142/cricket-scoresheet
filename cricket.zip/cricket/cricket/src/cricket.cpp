#include "cricket.h"
#include <iostream>
#include <cstdlib>
using namespace std;
string won,lose,elect,delect,venue,teams,competition,date;
int total1,total2,wicket1,wicket2;

void cricket::toss()
{
    cout<<"Enter the Name of competition: ";
    getline(cin,competition);
    cout<<"Enter a venue: ";
    getline(cin,venue);
    cout<<"Match between: ";
    getline(cin,teams);
    cout<<"Toss won by: ";
    getline(cin,won);
    cout<<"Elected to (bat/bowl): ";
    getline(cin,elect);
    if (elect=="bat")
    {
        delect="bowl";
    }
    else {delect="bat";}
    cout<<"Toss lose by: ";
    getline(cin,lose);
    cout<<"Enter a date(dd/mm/yyyy): ";
    cin>>date;
    cout<<endl;
    cout<<"________________________________________________________________________________"<<endl;
    cout<<"|";cout.width(20);cout<<"Competition Name: ";cout.width(20);cout<<competition<<" ||";cout.width(15);cout<<"Venue: ";cout.width(20);cout<<venue<<" |"<<endl;
    cout<<"________________________________________________________________________________"<<endl;
    cout<<"________________________________________________________________________________"<<endl;
    cout<<"|";cout.width(20);cout<<"Match between: ";cout.width(20);cout<<teams<<" ||";cout.width(15);cout<<"Date: ";cout.width(20);cout<<date<<" |"<<endl;
    cout<<"________________________________________________________________________________"<<endl;
    cout<<"________________________________________________________________________________"<<endl;
    cout<<"|";cout.width(20);cout<<"Toss won by: ";cout.width(20);cout<<won<<" ||";cout.width(15);cout<<"Elected to: ";cout.width(20);cout<<elect<<" |"<<endl;
    cout<<"________________________________________________________________________________"<<endl;
}

void cricket::inning1()
{
    cout<<endl;
    cout<<"********************************************************************************"<<endl;
    cout<<"*"<<"     Bating side     "<<"||     "<<won<<"     *"<<endl;
    cout<<"********************************************************************************"<<endl;
    int dan;
    cout<<"How many batsmen: ";
    cin>>dan;
    int one[dan],two[dan],four[dan],six[dan],run[dan];
    string namepl[dan];
    for(int i=1;i<=dan;i++)
    {
        cout<<endl<<"Name of batsman "<<i<<": ";
        cin>>namepl[i-1];
        cout<<endl;
        cout<<"One run: ";
        cin>>one[i-1];
        cout<<endl;
        cout<<"Two run: ";
        cin>>two[i-1];
        cout<<endl<<"Fours: ";
        cin>>four[i-1];
        cout<<endl<<"Sixes: ";
        cin>>six[i-1];
        cout<<endl;
        cout<<endl<<"Total runs of batsman "<<i<<": ";
        run[i-1]=(one[i-1]+(two[i-1]*2)+(four[i-1]*4)+(six[i-1]*6));
        cout<<run[i-1];
        cout<<endl;
        cout<<"__________________________________________________"<<endl;
        cout<<"Batsman name"<<" ||"<<" 1s"<<" ||"<<" 2s"<<" ||"<<" 4s"<<" ||"<<" 6s"<<" ||"<<" Total run"<<" |"<<endl;
        cout<<"__________________________________________________"<<endl;
        cout.width(12);cout<<namepl[i-1]<<" ||";cout.width(3);cout<<one[i-1]<<" ||";cout.width(3);cout<<two[i-1]<<" ||";cout.width(3);cout<<four[i-1]<<" ||";cout.width(3);cout<<six[i-1]<<" ||";cout.width(10);cout<<run[i-1]<<" |"<<endl;
        cout<<"__________________________________________________"<<endl;
        cout<<endl;
    }
    cout<<"********************************************************************************"<<endl;
    cout<<"*"<<"     Bowling side     "<<"||     "<<lose<<"     *"<<endl;
    cout<<"********************************************************************************"<<endl;
    int bowl;
    cout<<"How many bowlers: ";
    cin>>bowl;
    int average[bowl];
    int over[bowl],maiden[bowl],out[bowl],runs[bowl],bowler[bowl],wicket;
    string name[bowl];
    for(int i=1;i<=bowl;i++)
    {
        cout<<endl<<"Name of bowler "<<i<<": ";
        cin>>name[i-1];
        cout<<endl;
        cout<<"Enter the overs of the bowler "<<i<<": ";
        cin>>over[i-1];
        cout<<endl;
        cout<<"Total number of balls: ";
        bowler[i-1]=over[i-1]*6;
        cout<<bowler[i-1]<<endl;
        cout<<endl;
        cout<<"How many Maiden overs of the bowler"<<i<<": ";
        cin>>maiden[i-1];
        cout<<endl;
        cout<<"How many wickets bowler "<<i<<" took: ";
        cin>>out[i-1];
        cout<<endl;
        cout<<"Runs given by the bowler "<<i<<": ";
        cin>>runs[i-1];
        cout<<endl;
        cout<<"Economy: ";
        average[i-1]=runs[i-1]/over[i-1];
        cout<<average[i-1]<<endl;
        cout<<endl;
        cout<<"___________________________________________________________"<<endl;
        cout<<"Bowlers Name"<<" ||"<<"Overs"<<" ||"<<"Balls"<<" ||"<<"Maiden"<<" ||"<<"Runs"<<"/"<<"Out"<<" ||"<<"Economy"<<" |"<<endl;
        cout<<"___________________________________________________________"<<endl;
        cout.width(12);cout<<name[i-1]<<" ||";cout.width(5);cout<<over[i-1]<<" ||";cout.width(5);cout<<bowler[i-1]<<" ||";cout.width(6);cout<<maiden[i-1]<<" ||";cout.width(6);cout<<runs[i-1]<<"/"<<out[i-1]<<" ||";cout.width(7);cout<<average[i-1]<<" |"<<endl;
        cout<<"___________________________________________________________"<<endl;
}
cout<<endl<<endl<<endl;
    int sheet;
    cout<<"Click 1 to see the score sheet."<<endl;
    cin>>sheet;
    if(sheet==1)
    {
        cout<<"________________________________________________________________________________"<<endl;
        cout<<"|";cout.width(20);cout<<"Competition Name: ";cout.width(20);cout<<competition<<" ||";cout.width(15);cout<<"Venue: ";cout.width(20);cout<<venue<<" |"<<endl;
        cout<<"________________________________________________________________________________"<<endl;
        cout<<"________________________________________________________________________________"<<endl;
        cout<<"|";cout.width(20);cout<<"Match between: ";cout.width(20);cout<<teams<<" ||";cout.width(15);cout<<"Date: ";cout.width(20);cout<<date<<" |"<<endl;
        cout<<"________________________________________________________________________________"<<endl;
        cout<<"________________________________________________________________________________"<<endl;
        cout<<"|";cout.width(20);cout<<"Toss won by: ";cout.width(20);cout<<won<<" ||";cout.width(15);cout<<"Elected to: ";cout.width(20);cout<<elect<<" |"<<endl;
        cout<<"________________________________________________________________________________"<<endl;
        cout<<"________________________________________________________________________________"<<endl;
        cout<<"__________________________________________________"<<endl;
        cout<<"Batsman name"<<" ||"<<" 1s"<<" ||"<<" 2s"<<" ||"<<" 4s"<<" ||"<<" 6s"<<" ||"<<" Total run"<<" |"<<endl;
        cout<<"__________________________________________________"<<endl;
        for(int i=1;i<=dan;i++)
            {
                cout.width(12);cout<<namepl[i-1]<<" ||";cout.width(3);cout<<one[i-1]<<" ||";cout.width(3);cout<<two[i-1]<<" ||";cout.width(3);cout<<four[i-1]<<" ||";cout.width(3);cout<<six[i-1]<<" ||";cout.width(10);cout<<run[i-1]<<" |"<<endl;
            }
        cout<<"__________________________________________________"<<endl;
        cout<<"___________________________________________________________"<<endl;
        cout<<"Bowlers Name"<<" ||"<<"Overs"<<" ||"<<"Balls"<<" ||"<<"Maiden"<<" ||"<<"Runs"<<"/"<<"Out"<<" ||"<<"Economy"<<" |"<<endl;
        cout<<"___________________________________________________________"<<endl;
        for(int i=1;i<=bowl;i++)
           {
               cout.width(12);cout<<name[i-1]<<" ||";cout.width(5);cout<<over[i-1]<<" ||";cout.width(5);cout<<bowler[i-1]<<" ||";cout.width(6);cout<<maiden[i-1]<<" ||";cout.width(6);cout<<runs[i-1]<<"/"<<out[i-1]<<" ||";cout.width(7);cout<<average[i-1]<<" |"<<endl;
            }
        cout<<"___________________________________________________________"<<endl;
        total1=0;
        wicket1=0;
        for(int i=1;i<=dan;i++)
            {
                total1=total1+run[i-1];
            }
        for(int i=1;i<=bowl;i++)
        {
            wicket1=wicket1+out[i-1];
        }
        cout<<"\n\nTotal (Runs/wicket): "<<total1<<"/"<<wicket1<<endl<<endl;
    }
    else
    {
        cout<<"Ok Thanks"<<endl;
    }
}

void cricket::inning2()
{
    cout<<endl;
    cout<<"********************************************************************************"<<endl;
    cout<<"*"<<"     Batting side     "<<"||     "<<lose<<"     *"<<endl;
    cout<<"********************************************************************************"<<endl;
    int dan;
    cout<<"How many batsmen: ";
    cin>>dan;
    int one[dan],two[dan],four[dan],six[dan],run[dan];
    string namepl[dan];
    for(int i=1;i<=dan;i++)
    {
        cout<<endl<<"Name of batsman "<<i<<": ";
        cin>>namepl[i-1];
        cout<<endl;
        cout<<"One run: ";
        cin>>one[i-1];
        cout<<endl;
        cout<<"Two run: ";
        cin>>two[i-1];
        cout<<endl<<"Fours: ";
        cin>>four[i-1];
        cout<<endl<<"Sixes: ";
        cin>>six[i-1];
        cout<<endl;
        cout<<endl<<"Total runs of batsman "<<i<<": ";
        run[i-1]=(one[i-1]+(two[i-1]*2)+(four[i-1]*4)+(six[i-1]*6));
        cout<<run[i-1];
        cout<<endl;
        cout<<"__________________________________________________"<<endl;
        cout<<"Batsman name"<<" ||"<<" 1s"<<" ||"<<" 2s"<<" ||"<<" 4s"<<" ||"<<" 6s"<<" ||"<<" Total run"<<" |"<<endl;
        cout<<"__________________________________________________"<<endl;
        cout.width(12);cout<<namepl[i-1]<<" ||";cout.width(3);cout<<one[i-1]<<" ||";cout.width(3);cout<<two[i-1]<<" ||";cout.width(3);cout<<four[i-1]<<" ||";cout.width(3);cout<<six[i-1]<<" ||";cout.width(10);cout<<run[i-1]<<" |"<<endl;
        cout<<"__________________________________________________"<<endl;
        cout<<endl;
    }
    cout<<"********************************************************************************"<<endl;
    cout<<"*"<<"     Bowling side     "<<"||     "<<won<<"     *"<<endl;
    cout<<"********************************************************************************"<<endl;
    int bowl;
    cout<<"How many bowlers: ";
    cin>>bowl;
    int average[bowl];
    int over[bowl],maiden[bowl],out[bowl],runs[bowl],bowler[bowl];
    string name[bowl];
    for(int i=1;i<=bowl;i++)
    {
        cout<<endl<<"Name of bowler "<<i<<": ";
        cin>>name[i-1];
        cout<<endl;
        cout<<"Enter the overs of the bowler "<<i<<": ";
        cin>>over[i-1];
        cout<<endl;
        cout<<"Total number of balls: ";
        bowler[i-1]=over[i-1]*6;
        cout<<bowler[i-1]<<endl;
        cout<<endl;
        cout<<"How many Maiden overs of the bowler "<<i<<": ";
        cin>>maiden[i-1];
        cout<<endl;
        cout<<"How many wickets bowler "<<i<<" took: ";
        cin>>out[i-1];
        cout<<endl;
        cout<<"Runs given by the bowler "<<i<<": ";
        cin>>runs[i-1];
        cout<<"Economy: ";
        average[i-1]=runs[i-1]/over[i-1];
        cout<<average[i-1]<<endl;
        cout<<endl;
        cout<<"___________________________________________________________"<<endl;
        cout<<"Bowlers Name"<<" ||"<<"Overs"<<" ||"<<"Balls"<<" ||"<<"Maiden"<<" ||"<<"Runs"<<"/"<<"Out"<<" ||"<<"Economy"<<" |"<<endl;
        cout<<"___________________________________________________________"<<endl;
        cout.width(12);cout<<name[i-1]<<" ||";cout.width(5);cout<<over[i-1]<<" ||";cout.width(5);cout<<bowler[i-1]<<" ||";cout.width(6);cout<<maiden[i-1]<<" ||";cout.width(6);cout<<runs[i-1]<<"/"<<out[i-1]<<" ||";cout.width(7);cout<<average[i-1]<<" |"<<endl;
        cout<<"___________________________________________________________"<<endl;
}
cout<<endl<<endl<<endl;
    int sheet;
    cout<<"Click 1 to see the score sheet."<<endl;
    cin>>sheet;
    if(sheet==1)
    {
        cout<<"__________________________________________________"<<endl;
        cout<<"__________________________________________________"<<endl;
        cout<<"Batsman name"<<" ||"<<" 1s"<<" ||"<<" 2s"<<" ||"<<" 4s"<<" ||"<<" 6s"<<" ||"<<" Total run"<<" |"<<endl;
        cout<<"__________________________________________________"<<endl;
        for(int i=1;i<=dan;i++)
        {
            cout.width(12);cout<<namepl[i-1]<<" ||";cout.width(3);cout<<one[i-1]<<" ||";cout.width(3);cout<<two[i-1]<<" ||";cout.width(3);cout<<four[i-1]<<" ||";cout.width(3);cout<<six[i-1]<<" ||";cout.width(10);cout<<run[i-1]<<" |"<<endl;
        }
        cout<<"___________________________________________________________"<<endl;
        cout<<"___________________________________________________________"<<endl;
        cout<<"Bowlers Name"<<" ||"<<"Overs"<<" ||"<<"Balls"<<" ||"<<"Maiden"<<" ||"<<"Runs"<<"/"<<"Out"<<" ||"<<"Economy"<<" |"<<endl;
        cout<<"___________________________________________________________"<<endl;
        for(int i=1;i<=bowl;i++)
        {
            cout.width(12);cout<<name[i-1]<<" ||";cout.width(5);cout<<over[i-1]<<" ||";cout.width(5);cout<<bowler[i-1]<<" ||";cout.width(6);cout<<maiden[i-1]<<" ||";cout.width(6);cout<<runs[i-1]<<"/"<<out[i-1]<<" ||";cout.width(7);cout<<average[i-1]<<" |"<<endl;
        }
        cout<<"___________________________________________________________"<<endl;
        total2=0;
        wicket2=0;
        for(int i=1;i<=dan;i++)
            {
                total2=total2+run[i-1];
            }
        for(int i=1;i<=bowl;i++)
        {
            wicket2=wicket2+out[i-1];
        }
        cout<<"\n\nTotal (Runs/wicket): "<<total2<<"/"<<wicket2<<endl<<endl;
    }
    else
    {
        cout<<"Ok Thanks"<<endl;
    }
}
void cricket::innings()
{
    if (elect=="bat")
    {
        cout<<"________________________________________________________________________________"<<endl;
        cout<<"________________________________________________________________________________"<<endl;
        cout<<"******************************** For 1st Inning ********************************"<<endl;
        cout<<"________________________________________________________________________________"<<endl;
        cout<<"________________________________________________________________________________"<<endl;
        inning1();
        cout<<"Press 2 for continue with 2nd inning."<<endl;
        int num;
        cin>>num;
        if (num==2)
        {
            cout<<"________________________________________________________________________________"<<endl;
            cout<<"________________________________________________________________________________"<<endl;
            cout<<"******************************** For 2nd Inning ********************************"<<endl;
            cout<<"________________________________________________________________________________"<<endl;
            cout<<"________________________________________________________________________________"<<endl;
            inning2();
        }
        else {cout<<"Ok thanks.";}
    }
    else
    {
        cout<<"________________________________________________________________________________"<<endl;
        cout<<"________________________________________________________________________________"<<endl;
        cout<<"******************************** For 1st Inning ********************************"<<endl;
        cout<<"________________________________________________________________________________"<<endl;
        cout<<"________________________________________________________________________________"<<endl;
        inning2();
        cout<<"Press 2 for continue with 2nd inning."<<endl;
        int num;
        cin>>num;
        if (num==2)
        {
            cout<<"________________________________________________________________________________"<<endl;
            cout<<"________________________________________________________________________________"<<endl;
            cout<<"******************************** For 2nd Inning ********************************"<<endl;
            cout<<"________________________________________________________________________________"<<endl;
            cout<<"________________________________________________________________________________"<<endl;
            inning1();
        }
        else {cout<<"Ok thanks.";}
    }
}
    void cricket::winner()
    {
        if(total1>total2)
        {
            cout<<"Match won by "<<won<<endl;
        }
        else if(total2>total1)
        {
            cout<<"Match won by "<<lose<<endl;
        }
        else
        {
            cout<<"Match is draw."<<endl;
        }
    }
