#include <iostream>
#include <cstdlib>
#include "cricket.h"
using namespace std;

int main()
{
    system("color E1");
    cricket c;
    c.toss();
    c.innings();
    c.winner();
    return 0;
}
